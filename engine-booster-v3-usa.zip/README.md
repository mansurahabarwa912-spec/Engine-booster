# Engine Booster v3 - USA - Microsoft Edge Edition
## BROWSER: Microsoft Edge ONLY (Chromium) - NOT Internet Explorer
- Edge = Chromium, modern, supported. Use Edge.
- Internet Explorer 11 = retired June 15, 2022 by Microsoft. NOT supported. Do NOT open in IE.
- Test: open edge/edge-test.html in Edge - should say CORRECT - Microsoft Edge.
- Install as App in Edge: ... > Apps > Install this site as an app
- Open via protocol: microsoft-edge:https://enginebooster.app

## What's in v3
- v1: Bill -> PVWatts -> 19 ai_* fields
- v2: DSCR + Loan + Lender Matching
- v3: All above + Edge PWA manifest + Edge test page + GHL workflow v3 + C-PACE lender + 35 GHL fields

## Deploy
1. Unzip -> GitHub repo engine-booster
2. Render > New Web Service > Connect repo (render.yaml auto-detected)
3. Env: NREL_API_KEY, GHL_API_KEY, GHL_LOCATION_ID
4. GHL: Create 35 custom fields from ghl/engine-booster-workflow-v3.json
5. Test: curl -X POST https://YOUR-RENDER/api/v1/underwrite -H "Content-Type: application/json" -d '{"property_address":"1200 Industrial Way, Phoenix, AZ 85007","annual_kwh":245000,"electricity_rate_kwh":0.17,"annual_noi":420000}'

## Example Output
System 145kW, Cost $210k, ITC $63k, Net $147k, Savings $41k/yr, DSCR 1.42, Monthly $2,240, Best Lender GoodLeap, GREEN
